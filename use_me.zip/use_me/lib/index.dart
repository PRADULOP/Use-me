// Export pages
export 'login/login_widget.dart' show LoginWidget;
export 'create_account/create_account_widget.dart' show CreateAccountWidget;
export 'create_user/create_user_widget.dart' show CreateUserWidget;
export 'forgot_password/forgot_password_widget.dart' show ForgotPasswordWidget;
export 'profile_page/profile_page_widget.dart' show ProfilePageWidget;
export 'edit_profile/edit_profile_widget.dart' show EditProfileWidget;
export 'change_password/change_password_widget.dart' show ChangePasswordWidget;
export 'userreward/userreward_widget.dart' show UserrewardWidget;
export 'industrylogin/industrylogin_widget.dart' show IndustryloginWidget;
export 'industrydashboard/industrydashboard_widget.dart'
    show IndustrydashboardWidget;
export 'industrysettings/industrysettings_widget.dart'
    show IndustrysettingsWidget;
export 'rfidsensor/rfidsensor_widget.dart' show RfidsensorWidget;
export 'temperaturesensor/temperaturesensor_widget.dart'
    show TemperaturesensorWidget;
export 'infraredsensors/infraredsensors_widget.dart' show InfraredsensorsWidget;
export 'pressuresensor/pressuresensor_widget.dart' show PressuresensorWidget;
export 'levelsensors/levelsensors_widget.dart' show LevelsensorsWidget;
export 'gyroscope/gyroscope_widget.dart' show GyroscopeWidget;
export 'm_y_t_h_i_n_g_s_io_t_sensor/m_y_t_h_i_n_g_s_io_t_sensor_widget.dart'
    show MYTHINGSIoTSensorWidget;
export 'requestuser/requestuser_widget.dart' show RequestuserWidget;
export 'feedback/feedback_widget.dart' show FeedbackWidget;
export 'verifysms/verifysms_widget.dart' show VerifysmsWidget;
export 'wasteselection/wasteselection_widget.dart' show WasteselectionWidget;

import 'package:firebase_auth/firebase_auth.dart';
import 'package:rxdart/rxdart.dart';

class UseMeFirebaseUser {
  UseMeFirebaseUser(this.user);
  User user;
  bool get loggedIn => user != null;
}

UseMeFirebaseUser currentUser;
bool get loggedIn => currentUser?.loggedIn ?? false;
Stream<UseMeFirebaseUser> useMeFirebaseUserStream() => FirebaseAuth.instance
    .authStateChanges()
    .debounce((user) => user == null && !loggedIn
        ? TimerStream(true, const Duration(seconds: 1))
        : Stream.value(user))
    .map<UseMeFirebaseUser>((user) => currentUser = UseMeFirebaseUser(user));

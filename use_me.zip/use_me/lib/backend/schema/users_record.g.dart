// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'users_record.dart';

// **************************************************************************
// BuiltValueGenerator
// **************************************************************************

Serializer<UsersRecord> _$usersRecordSerializer = new _$UsersRecordSerializer();

class _$UsersRecordSerializer implements StructuredSerializer<UsersRecord> {
  @override
  final Iterable<Type> types = const [UsersRecord, _$UsersRecord];
  @override
  final String wireName = 'UsersRecord';

  @override
  Iterable<Object> serialize(Serializers serializers, UsersRecord object,
      {FullType specifiedType = FullType.unspecified}) {
    final result = <Object>[];
    Object value;
    value = object.createdTime;
    if (value != null) {
      result
        ..add('created_time')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(DateTime)));
    }
    value = object.email;
    if (value != null) {
      result
        ..add('email')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.displayName;
    if (value != null) {
      result
        ..add('display_name')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.password;
    if (value != null) {
      result
        ..add('password')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.photoUrl;
    if (value != null) {
      result
        ..add('photo_url')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.phoneNumber;
    if (value != null) {
      result
        ..add('phone_number')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.uid;
    if (value != null) {
      result
        ..add('uid')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.bio;
    if (value != null) {
      result
        ..add('bio')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.product;
    if (value != null) {
      result
        ..add('product')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(
                DocumentReference, const [const FullType(Object)])));
    }
    value = object.userCity;
    if (value != null) {
      result
        ..add('userCity')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.accountno;
    if (value != null) {
      result
        ..add('accountno')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.ifsc;
    if (value != null) {
      result
        ..add('ifsc')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.address;
    if (value != null) {
      result
        ..add('address')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.boxno;
    if (value != null) {
      result
        ..add('boxno')
        ..add(serializers.serialize(value, specifiedType: const FullType(int)));
    }
    value = object.typeofwaste;
    if (value != null) {
      result
        ..add('typeofwaste')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.feedback;
    if (value != null) {
      result
        ..add('feedback')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.reference;
    if (value != null) {
      result
        ..add('Document__Reference__Field')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(
                DocumentReference, const [const FullType(Object)])));
    }
    return result;
  }

  @override
  UsersRecord deserialize(Serializers serializers, Iterable<Object> serialized,
      {FullType specifiedType = FullType.unspecified}) {
    final result = new UsersRecordBuilder();

    final iterator = serialized.iterator;
    while (iterator.moveNext()) {
      final key = iterator.current as String;
      iterator.moveNext();
      final Object value = iterator.current;
      switch (key) {
        case 'created_time':
          result.createdTime = serializers.deserialize(value,
              specifiedType: const FullType(DateTime)) as DateTime;
          break;
        case 'email':
          result.email = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'display_name':
          result.displayName = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'password':
          result.password = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'photo_url':
          result.photoUrl = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'phone_number':
          result.phoneNumber = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'uid':
          result.uid = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'bio':
          result.bio = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'product':
          result.product = serializers.deserialize(value,
                  specifiedType: const FullType(
                      DocumentReference, const [const FullType(Object)]))
              as DocumentReference<Object>;
          break;
        case 'userCity':
          result.userCity = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'accountno':
          result.accountno = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'ifsc':
          result.ifsc = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'address':
          result.address = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'boxno':
          result.boxno = serializers.deserialize(value,
              specifiedType: const FullType(int)) as int;
          break;
        case 'typeofwaste':
          result.typeofwaste = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'feedback':
          result.feedback = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String;
          break;
        case 'Document__Reference__Field':
          result.reference = serializers.deserialize(value,
                  specifiedType: const FullType(
                      DocumentReference, const [const FullType(Object)]))
              as DocumentReference<Object>;
          break;
      }
    }

    return result.build();
  }
}

class _$UsersRecord extends UsersRecord {
  @override
  final DateTime createdTime;
  @override
  final String email;
  @override
  final String displayName;
  @override
  final String password;
  @override
  final String photoUrl;
  @override
  final String phoneNumber;
  @override
  final String uid;
  @override
  final String bio;
  @override
  final DocumentReference<Object> product;
  @override
  final String userCity;
  @override
  final String accountno;
  @override
  final String ifsc;
  @override
  final String address;
  @override
  final int boxno;
  @override
  final String typeofwaste;
  @override
  final String feedback;
  @override
  final DocumentReference<Object> reference;

  factory _$UsersRecord([void Function(UsersRecordBuilder) updates]) =>
      (new UsersRecordBuilder()..update(updates)).build();

  _$UsersRecord._(
      {this.createdTime,
      this.email,
      this.displayName,
      this.password,
      this.photoUrl,
      this.phoneNumber,
      this.uid,
      this.bio,
      this.product,
      this.userCity,
      this.accountno,
      this.ifsc,
      this.address,
      this.boxno,
      this.typeofwaste,
      this.feedback,
      this.reference})
      : super._();

  @override
  UsersRecord rebuild(void Function(UsersRecordBuilder) updates) =>
      (toBuilder()..update(updates)).build();

  @override
  UsersRecordBuilder toBuilder() => new UsersRecordBuilder()..replace(this);

  @override
  bool operator ==(Object other) {
    if (identical(other, this)) return true;
    return other is UsersRecord &&
        createdTime == other.createdTime &&
        email == other.email &&
        displayName == other.displayName &&
        password == other.password &&
        photoUrl == other.photoUrl &&
        phoneNumber == other.phoneNumber &&
        uid == other.uid &&
        bio == other.bio &&
        product == other.product &&
        userCity == other.userCity &&
        accountno == other.accountno &&
        ifsc == other.ifsc &&
        address == other.address &&
        boxno == other.boxno &&
        typeofwaste == other.typeofwaste &&
        feedback == other.feedback &&
        reference == other.reference;
  }

  @override
  int get hashCode {
    return $jf($jc(
        $jc(
            $jc(
                $jc(
                    $jc(
                        $jc(
                            $jc(
                                $jc(
                                    $jc(
                                        $jc(
                                            $jc(
                                                $jc(
                                                    $jc(
                                                        $jc(
                                                            $jc(
                                                                $jc(
                                                                    $jc(
                                                                        0,
                                                                        createdTime
                                                                            .hashCode),
                                                                    email
                                                                        .hashCode),
                                                                displayName
                                                                    .hashCode),
                                                            password.hashCode),
                                                        photoUrl.hashCode),
                                                    phoneNumber.hashCode),
                                                uid.hashCode),
                                            bio.hashCode),
                                        product.hashCode),
                                    userCity.hashCode),
                                accountno.hashCode),
                            ifsc.hashCode),
                        address.hashCode),
                    boxno.hashCode),
                typeofwaste.hashCode),
            feedback.hashCode),
        reference.hashCode));
  }

  @override
  String toString() {
    return (newBuiltValueToStringHelper('UsersRecord')
          ..add('createdTime', createdTime)
          ..add('email', email)
          ..add('displayName', displayName)
          ..add('password', password)
          ..add('photoUrl', photoUrl)
          ..add('phoneNumber', phoneNumber)
          ..add('uid', uid)
          ..add('bio', bio)
          ..add('product', product)
          ..add('userCity', userCity)
          ..add('accountno', accountno)
          ..add('ifsc', ifsc)
          ..add('address', address)
          ..add('boxno', boxno)
          ..add('typeofwaste', typeofwaste)
          ..add('feedback', feedback)
          ..add('reference', reference))
        .toString();
  }
}

class UsersRecordBuilder implements Builder<UsersRecord, UsersRecordBuilder> {
  _$UsersRecord _$v;

  DateTime _createdTime;
  DateTime get createdTime => _$this._createdTime;
  set createdTime(DateTime createdTime) => _$this._createdTime = createdTime;

  String _email;
  String get email => _$this._email;
  set email(String email) => _$this._email = email;

  String _displayName;
  String get displayName => _$this._displayName;
  set displayName(String displayName) => _$this._displayName = displayName;

  String _password;
  String get password => _$this._password;
  set password(String password) => _$this._password = password;

  String _photoUrl;
  String get photoUrl => _$this._photoUrl;
  set photoUrl(String photoUrl) => _$this._photoUrl = photoUrl;

  String _phoneNumber;
  String get phoneNumber => _$this._phoneNumber;
  set phoneNumber(String phoneNumber) => _$this._phoneNumber = phoneNumber;

  String _uid;
  String get uid => _$this._uid;
  set uid(String uid) => _$this._uid = uid;

  String _bio;
  String get bio => _$this._bio;
  set bio(String bio) => _$this._bio = bio;

  DocumentReference<Object> _product;
  DocumentReference<Object> get product => _$this._product;
  set product(DocumentReference<Object> product) => _$this._product = product;

  String _userCity;
  String get userCity => _$this._userCity;
  set userCity(String userCity) => _$this._userCity = userCity;

  String _accountno;
  String get accountno => _$this._accountno;
  set accountno(String accountno) => _$this._accountno = accountno;

  String _ifsc;
  String get ifsc => _$this._ifsc;
  set ifsc(String ifsc) => _$this._ifsc = ifsc;

  String _address;
  String get address => _$this._address;
  set address(String address) => _$this._address = address;

  int _boxno;
  int get boxno => _$this._boxno;
  set boxno(int boxno) => _$this._boxno = boxno;

  String _typeofwaste;
  String get typeofwaste => _$this._typeofwaste;
  set typeofwaste(String typeofwaste) => _$this._typeofwaste = typeofwaste;

  String _feedback;
  String get feedback => _$this._feedback;
  set feedback(String feedback) => _$this._feedback = feedback;

  DocumentReference<Object> _reference;
  DocumentReference<Object> get reference => _$this._reference;
  set reference(DocumentReference<Object> reference) =>
      _$this._reference = reference;

  UsersRecordBuilder() {
    UsersRecord._initializeBuilder(this);
  }

  UsersRecordBuilder get _$this {
    final $v = _$v;
    if ($v != null) {
      _createdTime = $v.createdTime;
      _email = $v.email;
      _displayName = $v.displayName;
      _password = $v.password;
      _photoUrl = $v.photoUrl;
      _phoneNumber = $v.phoneNumber;
      _uid = $v.uid;
      _bio = $v.bio;
      _product = $v.product;
      _userCity = $v.userCity;
      _accountno = $v.accountno;
      _ifsc = $v.ifsc;
      _address = $v.address;
      _boxno = $v.boxno;
      _typeofwaste = $v.typeofwaste;
      _feedback = $v.feedback;
      _reference = $v.reference;
      _$v = null;
    }
    return this;
  }

  @override
  void replace(UsersRecord other) {
    ArgumentError.checkNotNull(other, 'other');
    _$v = other as _$UsersRecord;
  }

  @override
  void update(void Function(UsersRecordBuilder) updates) {
    if (updates != null) updates(this);
  }

  @override
  _$UsersRecord build() {
    final _$result = _$v ??
        new _$UsersRecord._(
            createdTime: createdTime,
            email: email,
            displayName: displayName,
            password: password,
            photoUrl: photoUrl,
            phoneNumber: phoneNumber,
            uid: uid,
            bio: bio,
            product: product,
            userCity: userCity,
            accountno: accountno,
            ifsc: ifsc,
            address: address,
            boxno: boxno,
            typeofwaste: typeofwaste,
            feedback: feedback,
            reference: reference);
    replace(_$result);
    return _$result;
  }
}

// ignore_for_file: always_put_control_body_on_new_line,always_specify_types,annotate_overrides,avoid_annotating_with_dynamic,avoid_as,avoid_catches_without_on_clauses,avoid_returning_this,deprecated_member_use_from_same_package,lines_longer_than_80_chars,omit_local_variable_types,prefer_expression_function_bodies,sort_constructors_first,test_types_in_equals,unnecessary_const,unnecessary_new
